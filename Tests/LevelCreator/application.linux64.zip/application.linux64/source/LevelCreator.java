import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class LevelCreator extends PApplet {

public void setup() {
  size(800,460);
  frameRate(2000);
}
int i;
float a;
float s;
public void draw(){
  fill (0);
  i = i + 5;
  a = a + random(-30,30);
  s = s + random(-2,2);
  ellipse(i,240+a,10 + s,10 + s);
  if ( i > 800 ) {
    filter(BLUR,10);
    filter(THRESHOLD,0.3f);
    noLoop();
  } else {
    i = i+2;
    a = a + random(-20,20);
    s = s + random(-2,2);
    ellipse(i,240+a,60 + s,60 + s);
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "--full-screen", "--bgcolor=#666666", "--stop-color=#cccccc", "LevelCreator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
